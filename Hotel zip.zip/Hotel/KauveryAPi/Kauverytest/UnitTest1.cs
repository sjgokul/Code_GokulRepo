using KauveryHotel.Controllers;
using KauveryHotel.Models;
using KauveryHotel.Models.DTO;
using KauveryHotel.Repository;
using Moq;
using System.Diagnostics.Metrics;

namespace Kauverytest
{
    public class UnitTest1
    {
        [Fact]
        public async Task Test1Async()
        {
            var mockRepo = new Mock<Ikauvery>();
            mockRepo.Setup(x => x.GetMenuItems()).ReturnsAsync(AddMenuItems);
            var controller = new KauveryController(mockRepo.Object);
            ResponseDTO response = new ResponseDTO();
            response = (ResponseDTO)await controller.GetMenuItems();
            IEnumerable<MenuItem> con = (IEnumerable<MenuItem>)response.Result;
            Assert.Equal(2, con.ToList<MenuItem>().Count());
        }

        public List<MenuItem> AddMenuItems()
        {
            List<MenuItem> menuItems = new List<MenuItem>();
            menuItems.Add(new MenuItem
            {
                menu_Id = 7,
                menu_Name = "Biriyani"
            });
            menuItems.Add(new MenuItem
            {
                menu_Id = 8,
                menu_Name = "Friedrice"

            });
            return menuItems;


        }

    }
}
