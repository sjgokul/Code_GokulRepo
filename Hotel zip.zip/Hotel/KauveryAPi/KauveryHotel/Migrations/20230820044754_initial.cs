﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KauveryHotel.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "users",
                columns: table => new
                {
                    user_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    user_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    user_Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    user_Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    user_Role = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_users", x => x.user_Id);
                });

            migrationBuilder.CreateTable(
                name: "restraunts",
                columns: table => new
                {
                    restraunt_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    restraunt_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    restraunt_Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    restraunt_Location = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    owner_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_restraunts", x => x.restraunt_Id);
                    table.ForeignKey(
                        name: "FK_restraunts_users_owner_id",
                        column: x => x.owner_id,
                        principalTable: "users",
                        principalColumn: "user_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "menuitems",
                columns: table => new
                {
                    menu_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    restaurant_id = table.Column<int>(type: "int", nullable: false),
                    menu_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    menu_Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    menu_Price = table.Column<double>(type: "float", nullable: false),
                    menu_Availablity = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_menuitems", x => x.menu_Id);
                    table.ForeignKey(
                        name: "FK_menuitems_restraunts_restaurant_id",
                        column: x => x.restaurant_id,
                        principalTable: "restraunts",
                        principalColumn: "restraunt_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "orders",
                columns: table => new
                {
                    order_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    user_ID = table.Column<int>(type: "int", nullable: false),
                    restaurant_id = table.Column<int>(type: "int", nullable: false),
                    order_Date = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    order_Status = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orders", x => x.order_Id);
                    table.ForeignKey(
                        name: "FK_orders_restraunts_restaurant_id",
                        column: x => x.restaurant_id,
                        principalTable: "restraunts",
                        principalColumn: "restraunt_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrderItems",
                columns: table => new
                {
                    order_ID = table.Column<int>(type: "int", nullable: false),
                    menu_item_id = table.Column<int>(type: "int", nullable: false),
                    orderitem_Quantity = table.Column<int>(type: "int", nullable: false),
                    orderitem_Price = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.ForeignKey(
                        name: "FK_OrderItems_menuitems_menu_item_id",
                        column: x => x.menu_item_id,
                        principalTable: "menuitems",
                        principalColumn: "menu_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_menuitems_restaurant_id",
                table: "menuitems",
                column: "restaurant_id");

            migrationBuilder.CreateIndex(
                name: "IX_OrderItems_menu_item_id",
                table: "OrderItems",
                column: "menu_item_id");

            migrationBuilder.CreateIndex(
                name: "IX_orders_restaurant_id",
                table: "orders",
                column: "restaurant_id");

            migrationBuilder.CreateIndex(
                name: "IX_restraunts_owner_id",
                table: "restraunts",
                column: "owner_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrderItems");

            migrationBuilder.DropTable(
                name: "orders");

            migrationBuilder.DropTable(
                name: "menuitems");

            migrationBuilder.DropTable(
                name: "restraunts");

            migrationBuilder.DropTable(
                name: "users");
        }
    }
}
