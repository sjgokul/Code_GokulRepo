﻿using KauveryHotel.Models;

namespace KauveryHotel.Repository
{
    public interface Ikauvery
    {
        public Task<List<Restraunt>> RetrieveRestraunt();
        public Task<List<MenuItem>> GetMenuItems();
        public Task<MenuItem> PlaceOrders(MenuItem items);
        public Task<OrderItem>ViewOrderHistory(int id);
        public Task<Order> ViewOrderStatus(int id);

        public Task<Order> UpdateOrderStatus(int orderid);


        

    }
}
