﻿using KauveryHotel.DBContext;
using KauveryHotel.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.EntityFrameworkCore;

namespace KauveryHotel.Repository
{
    public class KauveryRepository : Ikauvery
    {
      public   Kauvery_DbContext _dbContext;

        public KauveryRepository(Kauvery_DbContext dbContext)
        {
            try
            {
                _dbContext = dbContext;
            }
            catch (Exception)
            {

                Console.WriteLine("Invalid Initialiization");
            }
        }
        public  async Task<List<Restraunt>> RetrieveRestraunt()
        {
            try
            {
                List<Restraunt> restrauntlist = await _dbContext.restraunts.ToListAsync();
                return restrauntlist;
            }
            catch (Exception)
            {

                return null;
            }


        }
        public async  Task<List<MenuItem>> GetMenuItems()
        {
            try
            {
                List<MenuItem> list = await _dbContext.menuitems.ToListAsync();
                return list;
            }
            catch (Exception)
            {

                return null;
            }
        }

        public async  Task<MenuItem> PlaceOrders(MenuItem items)
        {
            try
            {
                _dbContext.menuitems.Add(items);
                await _dbContext.SaveChangesAsync();
                return items;
            }
            catch (Exception)
            {

                return null;
            }
        }

        

        public  async  Task<Order> UpdateOrderStatus(int  orderid)
        {
            try
            {
                var status =  from ex in _dbContext.orders
                             where
                            (ex.order_Id == orderid)
                             select ex;
                foreach(var x in status)
                {
                    x.order_Status = "Delivered";
                }

                 _dbContext.SaveChanges();
                return (Order)status;
 
            }
            catch (Exception)
            {

                return null;
            }
            

        }

        public async  Task<OrderItem> ViewOrderHistory(int id)
        {

            try
            {
                OrderItem orderItem = _dbContext.OrderItems.Where(x => x.order_ID == id).FirstOrDefault();
                return orderItem;
            }
            catch (Exception)
            {

                return null;
            }
        }

        public async Task<Order> ViewOrderStatus(int id)
        {
            try
            {
                Order orderstatus = _dbContext.orders.Where(x => x.order_Id == id).FirstOrDefault();
                return orderstatus;
            }
            catch (Exception)
            {

                return null;
            }
        }
    }
}
