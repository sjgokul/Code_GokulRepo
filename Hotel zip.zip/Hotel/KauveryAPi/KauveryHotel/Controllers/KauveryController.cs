﻿using Azure;
using KauveryHotel.Models;
using KauveryHotel.Models.DTO;
using KauveryHotel.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KauveryHotel.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class KauveryController : ControllerBase
    {
        public Ikauvery _kauvery;
        public  ResponseDTO _response;

        public KauveryController(Ikauvery kauvery)
        {
            _kauvery = kauvery;
            this._response = new ResponseDTO();

        }


        [HttpGet]
        public async Task<object> GetRestrauntDeatails()
        {
            var retrieverestaurantid = await  _kauvery.RetrieveRestraunt();
            try
            {
                if (retrieverestaurantid == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;

                }
                _response.isSuccess = true;
                _response.Result = retrieverestaurantid;
                return _response;
            }
            catch (Exception)
            {

                Console.WriteLine("Exception Handled");
            }
            return retrieverestaurantid;


        }
        [HttpGet]
        public async Task<object> GetMenuItems()
        {
            var MenuItems = await _kauvery.GetMenuItems();
            try
            {
                if (MenuItems == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;

                }
                _response.isSuccess = true;
                _response.Result = MenuItems;
                return _response;
            }
            catch (Exception)
            {

                Console.WriteLine("Exception Handled");
            }
            return MenuItems;


        }

        [HttpGet("{id}")]
        public async Task<object> GetOrderStatus(int id)
        {
            var vieworderhistory = await _kauvery.ViewOrderStatus(id);
            try
            {
                
                if (vieworderhistory == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Null id";
                    return _response;
                }
                _response.isSuccess = true;
                _response.Result = vieworderhistory;
                return _response;
            }
            catch (Exception)
            {

                Console.WriteLine("Exception handled");
            }

            return vieworderhistory;
        }

        [HttpPut("{id}")]
        public async Task<object> PutStatus(int id)
        {
            var update = _kauvery.UpdateOrderStatus(id);
            try
            {
                if (update == null)
                {
                    _response.Result = false;
                    _response.ErrorMessage = "No updation occurs";
                    return _response;
                }
                _response.isSuccess = true;
                _response.Result = update;
                return _response.Result;
            }
           
            catch (Exception)
            {

                Console.WriteLine("Status update Failed !");
            }
            return update;
            
        }

        [HttpPost]
        public async Task<object> PlaceOrders(MenuItem items)
        {
            var orderplace =  _kauvery.PlaceOrders(items);
            try
            {
                if (items == null)
                {
                    _response.Result = false;
                    _response.ErrorMessage = "Invalid order placed";
                    return _response;
                }
                _response.isSuccess = true;
                _response.Result = orderplace;
                return _response.Result;
            }
            catch (Exception)
            {

                Console.WriteLine($"you have ordered an item that is not in the list : {items}");
            }
            return orderplace;
        }


    }
}
