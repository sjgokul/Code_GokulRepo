﻿using KauveryHotel.Models;
using Microsoft.EntityFrameworkCore;

namespace KauveryHotel.DBContext
{
    public class Kauvery_DbContext:DbContext
    {
        public DbSet<MenuItem>menuitems { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<Order> orders { get; set; }
        public DbSet<Restraunt> restraunts { get; set; }
        public DbSet<User> users { get; set; }

        public Kauvery_DbContext(DbContextOptions<Kauvery_DbContext>options):base(options)
        {
            
        }

    }
}
