﻿namespace KauveryHotel.Models.DTO
{
    public class ResponseDTO
    {
        public bool isSuccess { get; set; }
        public string DisplayMessage { get; set; }

        public object Result { get;set; }

        public string ErrorMessage { get;set; }
    }
}
