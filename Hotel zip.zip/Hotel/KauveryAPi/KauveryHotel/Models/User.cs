﻿using System.ComponentModel.DataAnnotations;

namespace KauveryHotel.Models
{
    public class User
    {
        [Key] 
        public int user_Id { get; set; }
        public string user_Name { get; set; }
        public string user_Email { get; set; }
        public string user_Password { get; set; }
        public string user_Role { get; set; }
    }
}
