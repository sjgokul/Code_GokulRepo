﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KauveryHotel.Models
{
    public class Order
    {
        [Key]
        public int order_Id { get; set; }
        
        [ForeignKey("user_id")]
        public  int user_ID { get; set; }
        
        [ForeignKey("restaurant_id")]
        public Restraunt restraunt_ID { get; set; }

        public string order_Date { get;set; }

        public string order_Status { get; set; }



    }
}
