﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KauveryHotel.Models
{
    public class Restraunt
    {
        [Key]
        public int restraunt_Id { get; set; }

        public string restraunt_Name { get; set; }

        public string restraunt_Description { get; set; }
        public string restraunt_Location {get;set;}
        [ForeignKey("owner_id")]
        public User user_ID { get; set; }
    }
}
