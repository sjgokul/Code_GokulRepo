﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KauveryHotel.Models
{
    [Keyless]
    public class OrderItem
    {
        
        [ForeignKey("order_id")]
        public int order_ID { get; set; }

        [ForeignKey("menu_item_id")]
        public MenuItem menu_ID { get; set; }
        public int orderitem_Quantity { get; set; }

        public double orderitem_Price { get; set;}
        
    }
}
