﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KauveryHotel.Models
{
    public class MenuItem
    {
        [Key]
        public int menu_Id { get; set; }

        [ForeignKey("restaurant_id")]
        public Restraunt restraunt_ID { get; set; }

        public string menu_Name { get; set; }

        public string menu_Description { get;set; }
        public double menu_Price { get; set; }

        public string menu_Availablity { get;set; }


    }
}
