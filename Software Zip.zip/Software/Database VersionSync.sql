use VersionSyncDatabase

select  * from Apps
select * from Versions

INSERT INTO Versions Values
(1, 1, '95.0.4638.69', '2023-10-01', 'Bug fixes and performance improvements'),
(2, 2, '2022.0.1', '2023-09-28', 'Improved AI tools and enhanced performance'),
(3, 3, '4.20.0', '2023-10-05', 'New UI enhancements and improved notifications'),
(4, 4, '16.52', '2023-10-10', 'Enhanced collaboration features and bug fixes'),
(5, 5, '1.1.68.632', '2023-09-30', 'Added new playlist sharing feature and bug fixes'),
(6, 6, '5.8.0 (743)', '2023-10-02', 'Improved security and audio enhancements'),
(7, 7, '2022 Preview 2', '2023-10-12', 'Added new debugging tools and enhanced code navigation'),
(8, 8, '3.0.16', '2023-09-25', 'Updated codec support and improved playback performance'),
(9, 9, '2.0.14', '2023-10-08', 'Added new task management features and improved interface'),
(10, 10, '27.0.1', '2023-10-15', 'Improved recording quality and added new streaming options'),
(11, 11, '1.49.23636.15383', '2023-10-06', 'Enhanced file sharing and increased storage capacity'),
(12, 12, '2.9.3', '2023-09-29', 'Improved repository management and bug fixes'),
(13, 13, '2022.0.2', '2023-10-11', 'Added new video editing tools and enhanced performance'),
(14, 14, '2021.2.3', '2023-10-09', 'Added new code refactoring tools and improved UI'),
(15, 15, '1.31.88', '2023-10-07', 'Improved privacy features and enhanced browsing speed');

insert into Versions values
(1,1, '94.0.4606.71', 'Bug fixes and performance improvements', '1634822400', '2023-09-21', 'No', '200'),
(2, 2, '1.1.68.632',  'Improved AI tools and enhanced performance', '1630329600', '2023-08-30', 'No', '150'),
(3, 3, '2022',  'New UI enhancements and improved notifications', '1632691200', '2023-09-27', 'Yes', '300'),
(4, 4, '22.0.0', 'Enhanced collaboration features and bug fixes', '1633046400', '2023-10-01', 'No', '250'),
(5, 5, '16.52', 'Added new playlist sharing feature and bug fixes', '1631664000', '2023-09-15', 'No', '180'),
(6, 6, '5.8.0', 'Improved security and audio enhancements', '1633392000', '2023-10-05', 'Yes', '220'),
(7, 7, '2.21.18.17',  'Added new debugging tools and enhanced code navigation', '1633838400', '2023-10-10', 'No', '190'),
(8, 8, '3.0.16',  'Updated codec support and improved playback performance', '1634745600', '2023-09-20', 'No',' 210'),
(9, 9, '134.4.4261', 'Added new task management features and improved interface', '1634016000', '2023-10-12', 'Yes', '280'),
(10, 10, '2.9.6',  'Improved recording quality and added new streaming options', '1629868800', '2023-08-25', 'No',' 160'),
(11, 11, '3.55.1', 'Enhanced file sharing and increased storage capacity', '1630761600', '2023-09-05', 'No',' 230'),
(12, 12, '27.0.1',   'Improved repository management and bug fixes', '1634265600', '2023-10-15', 'Yes', '320'),
(13, 13, '2021.2.3', 'Added new video editing tools and enhanced performance', '1634553600', '2023-10-18', 'No',' 260'),
(14, 14, '4.20.0',  'Added new code refactoring tools and improved UI', '1632758400', '2023-09-28', 'No', '170'),
(15, 15, '26.0.0',  'Improved privacy features and enhanced browsing speed',' 1634640000', '2023-10-20', 'Yes', '340');




INSERT INTO Apps VALUES 
(1, 'Chrome', 'Web browser developed by Google', '95.0.4638.69','96.0.4.6', 'Active'),
(2, 'Photoshop', 'Image editing software by Adobe', '74.11.23','2022.0.1', 'Active'),
(3, 'Slack', 'Business communication platform', '4.0.0','4.20.0', 'Active'),
(4, 'Microsoft Word', 'Word processing software by Microsoft', '16.60','16.52', 'Active'),
(5, 'Spotify', 'Music streaming service', '1.1.68.632', '1,1,67,63','Active'),
(6, 'Zoom', 'Video conferencing software', '5.8.0 (743)','5.8.0 (700)', 'Active'),
(7, 'Visual Studio', 'Integrated development environment','2022 Preview 3','2022 Preview 2', 'Active'),
(8, 'VLC Media Player', 'Multimedia player', '3.0.10','3.0.16', 'Active'),
(9, 'Notion', 'Collaboration tool', '2.0.14', '2.0.11','Active'),
(10, 'OBS Studio', 'Video recording and live streaming software', '27.2.2.2','27.0.1', 'Active'),
(11, 'Google Drive', 'Cloud storage and file backup service', '1.48.23635.123231','1.49.23636.15383', 'Active'),
(12, 'GitHub Desktop', 'Git client', '2.9.3', '2.2.2','Active'),
(13, 'Adobe Premiere Pro', 'Video editing software by Adobe', '2022.0.2', '2022.02','Active'),
(14, 'IntelliJ IDEA', 'Java integrated development environment', '2021.2.3', '2021.2.1','Active'),
(15, 'Brave Browser', 'Web browser focused on privacy', '1.31.88', '1.23.9','Active');


delete from Versions where VersionId =1