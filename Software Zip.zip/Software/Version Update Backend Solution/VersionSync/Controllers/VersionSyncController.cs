﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq.Expressions;
using VersionSync.Models;
using VersionSync.Models.DTO;
using VersionSync.Repository;
using static System.Net.Mime.MediaTypeNames;
using Application = VersionSync.Models.Application;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VersionSync.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class VersionSyncController : ControllerBase
    {
        IVersionSync _db;
        ResponseDTO _response;

        public VersionSyncController(IVersionSync db)
        {
            _db = db;
            this._response = new ResponseDTO();

        }

        // GET: api/<VersionSyncController>
        [HttpGet]
        public async Task<object> GetApplications()
        {
            try
            {
                var getallapp = await _db.GetAllApplication();
                if (getallapp == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;
                }
                else
                {
                    _response.isSuccess = true;
                    _response.Result = getallapp;
                    return _response;
                }


            }
            catch (BadHttpRequestException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
                return null;
            }


        }
        [HttpGet]
        public async Task<object> GetAppById(int applicationid)
        {
            try
            {
                var getallapp = await _db.GetApplication(applicationid);
                if (getallapp == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;
                }
                else
                {
                    _response.isSuccess = true;
                    _response.Result = getallapp;
                    return _response;
                }


            }
            catch (BadHttpRequestException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
                return null;
            }


        }
        [HttpGet]
        public async Task<object> GetVersionsions(int Versionsid)
        {
            try
            {
                var getversionbyid = await _db.GetVersionsions(Versionsid);
                if (getversionbyid == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;
                }
                else
                {
                    _response.isSuccess = true;
                    _response.Result = getversionbyid;
                    return _response;
                }


            }
            catch (BadHttpRequestException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
                return null;
            }


        }
      
        [HttpPost]
        public async Task<object> UpdateApplication(Application Updateapplication)
        {
            try
            {
                var getversionbyid = await _db.UpdateApplication(Updateapplication);
                if (getversionbyid == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;
                }
                else
                {
                    _response.isSuccess = true;
                    _response.Result = getversionbyid;
                    return _response;
                }


            }
            catch (BadHttpRequestException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
                return null;
            }


        }
        [HttpPost]
        public async Task<object> UpdateVersions(VersionHistory UpdateVersions)
        {
            try
            {
                var getversionbyid = await _db.UpdateVersions( UpdateVersions);
                if (getversionbyid == null)
                {
                    _response.isSuccess = false;
                    _response.DisplayMessage = "Invalid";
                    return _response;
                }
                else
                {
                    _response.isSuccess = true;
                    _response.Result = getversionbyid;
                    return _response;
                }


            }
            catch (BadHttpRequestException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
                return null;
            }


        }
       
              
        
    }
}
