﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace VersionSync.Models
{
    public class Application
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int applicationId { get; set; }
        public string applicationName { get; set; }
        public string applicationDescription { get; set; }  
        public string applicationCurrentVersion { get; set; }
        public string applicationRecommendedVersion { get; set; }
        public string status { get; set; }



    }
}
