﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VersionSync.Models
{
    public class VersionHistory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int VersionId { get; set; }
        
        [ForeignKey("applicationId")]
        public Application applicationID {  get; set; }
        
        public string versionNumber { get; set; }
        public string releaseNotes { get;set; }
        public string timeStramp { get; set; }
        public string releaseDate { get; set; }
        public string restartRequired { get; set; }
        public string totalComponents { get; set; } 
 

    }
}
