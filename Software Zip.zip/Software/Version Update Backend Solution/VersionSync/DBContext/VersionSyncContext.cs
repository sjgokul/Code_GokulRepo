﻿using Microsoft.EntityFrameworkCore;
using VersionSync.Models;

namespace VersionSync.DBContext
{
    public class VersionSyncContext:DbContext
    {
       public DbSet<VersionHistory> Versions { get; set;}
       public DbSet<Application> Apps { get; set;}


        public VersionSyncContext(DbContextOptions<VersionSyncContext>options):base(options) 
        
        {
            
        }
    }
}
