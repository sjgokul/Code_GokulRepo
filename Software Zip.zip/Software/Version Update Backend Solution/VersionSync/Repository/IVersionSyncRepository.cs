﻿using Microsoft.AspNetCore.Server.IIS;
using Microsoft.EntityFrameworkCore;
using System;
using VersionSync.DBContext;
using VersionSync.Models;
using BadHttpRequestException = Microsoft.AspNetCore.Http.BadHttpRequestException;

namespace VersionSync.Repository
{
    public class IVersionSyncRepository : IVersionSync
    {
        public VersionSyncContext _dbContext;

        public IVersionSyncRepository(VersionSyncContext dbContext)
        {
            try
            {
                _dbContext = dbContext;
            }
            catch (BadHttpRequestException ex)
            {

                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid Initialiization");
            }
           
        }
        public async Task<Application> AddNewApplication(Application newapplicationdetails)
        {
            try
            {
                _dbContext.Apps.Add(newapplicationdetails);
                await _dbContext.SaveChangesAsync();
                return newapplicationdetails;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }

        public async  Task<VersionHistory> AddNewVersion(VersionHistory newversionHistoryDetails)
        {
            try
            {
                _dbContext.Versions.Add(newversionHistoryDetails);
                await _dbContext.SaveChangesAsync();
                return newversionHistoryDetails;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }

        public async Task<List<Application>> GetAllApplication()
        {
            try
            {
                List<Application> applicationDetails = await _dbContext.Apps.ToListAsync();
                return applicationDetails;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }


        public async Task<Application> GetApplication(int applicationid)
        {
            try
            {
                Application applications = _dbContext.Apps.Where(x => x.applicationId == applicationid).FirstOrDefault();
                return applications;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }

        public async Task<VersionHistory> GetVersionsions(int Versionsid)
        {
            try
            {
                VersionHistory applications = _dbContext.Versions.Where(x => x.VersionId == Versionsid).FirstOrDefault();
                return applications;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }

        public async  Task<Application> UpdateApplication(Application Updateapplication)
        {
            try
            {
                _dbContext.Apps.Add(Updateapplication);
                await _dbContext.SaveChangesAsync();
                return Updateapplication;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }

        public async Task<VersionHistory> UpdateVersions(VersionHistory UpdateVersions)
        {
            try
            {
                _dbContext.Versions.Add(UpdateVersions);
                await _dbContext.SaveChangesAsync();
                return UpdateVersions;
            }
            catch (BadHttpRequestException ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine("Invalid");
            }
            return null;
        }
    }
}
