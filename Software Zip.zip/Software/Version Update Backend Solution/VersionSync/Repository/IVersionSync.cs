﻿using VersionSync.Models;

namespace VersionSync.Repository
{
    public interface IVersionSync
    {

        public Task<Application> AddNewApplication(Application newapplicationdetails);
        public Task<VersionHistory> AddNewVersion(VersionHistory newversionHistoryDetails);
        public Task<List<Application>> GetAllApplication();
        public Task<Application> GetApplication(int applicationid);
        public Task<VersionHistory> GetVersionsions(int Versionsid);
        public Task<Application> UpdateApplication(Application Updateapplication);
        public Task<VersionHistory> UpdateVersions(VersionHistory UpdateVersions);
    }
}
