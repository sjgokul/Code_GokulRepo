﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VersionSync.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Apps",
                columns: table => new
                {
                    applicationId = table.Column<int>(type: "int", nullable: false),
                    applicationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    applicationDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    applicationCurrentVersion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    applicationRecommendedVersion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    status = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Apps", x => x.applicationId);
                });

            migrationBuilder.CreateTable(
                name: "Versions",
                columns: table => new
                {
                    VersionId = table.Column<int>(type: "int", nullable: false),
                    applicationId = table.Column<int>(type: "int", nullable: false),
                    versionNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    releaseNotes = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    timeStramp = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    releaseDate = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    restartRequired = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    totalComponents = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Versions", x => x.VersionId);
                    table.ForeignKey(
                        name: "FK_Versions_Apps_applicationId",
                        column: x => x.applicationId,
                        principalTable: "Apps",
                        principalColumn: "applicationId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Versions_applicationId",
                table: "Versions",
                column: "applicationId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Versions");

            migrationBuilder.DropTable(
                name: "Apps");
        }
    }
}
